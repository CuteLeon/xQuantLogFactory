﻿using System;

namespace xQuant.LogParser
{
    public interface ITrace
    {
        void Write(string info);
    }

    public class Trace : ITrace
    {
        public void Write(string info)
        {
            Console.WriteLine(string.Format("{0} {1}", DateTime.Now.ToString("HH:mm:ss"), info));
        }

        public static Trace Default = new Trace();
    }
}
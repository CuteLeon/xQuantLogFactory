﻿using System.Collections.Generic;

namespace xQuant.LogParser
{
    /// <summary>
    /// 日志分析器
    /// </summary>
    public class LogParser
    {
        private ITrace trace = new Trace();

        public void Execute(string[] args)
        {
            // 解析日志分析参数
            var param = AnalysisParam.Parse(args);

            this.Execute(param);
        }

        public void Execute(AnalysisParam param)
        {
            // 读取日志监控项目
            MonitorContainer container = MonitorContainer.Default;

            // 读取待分析的日志文件
            var fileFinder = new FileFinder();
            List<LogFile> logFileList = fileFinder.Execute(param);

            // 解析日志文件
            List<MonitorItemResult> itemResultList = new List<MonitorItemResult>();
            ILogParser parser = new Parser();
            foreach (var file in logFileList)
            {
                var items = parser.Execute(file, container.ItemList);
                if (items != null && items.Count > 0)
                {
                    itemResultList.AddRange(items);
                }
            }

            // 分析日志解析结果
            var analysis = new Analysis();
            analysis.Execute(itemResultList);

            // 生成日志分析报告
            var exporter = new LogReportExporter();
            exporter.Execute(param, itemResultList);
        }
    }
}
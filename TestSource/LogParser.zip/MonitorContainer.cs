﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace xQuant.LogParser
{
    /// <summary>
    /// 监控项目容器
    /// </summary>
    [Serializable]
    [XmlRoot("Root")]
    public class MonitorContainer
    {
        /// <summary>
        /// 监控项目列表
        /// </summary>
        [XmlElement("Item")]
        public List<MonitorItem> ItemList { get; set; }

        public static MonitorContainer Default
        {
            get
            {
                MonitorItem rootItem = new MonitorItem
                {
                    ItemName = "客户端启动",
                    StartPattern = "客户端启动开始",
                    FinishPatterny = "初始化第二阶段开始",
                    ChildList = new List<MonitorItem>{  
                    new MonitorItem{ ItemName="数据加载",
                        StartPattern="加载中债参数设置表", 
                        FinishPatterny="加载当前登录部门",
                        ChildList= new List<MonitorItem>{
                            new MonitorItem{ 
                                ItemName="债券加载",
                                StartPattern="加载TBND查询", 
                                FinishPatterny="加载TBND"}}} 
                    }
                };

                var containor = new MonitorContainer();
                containor.ItemList = new List<MonitorItem> { rootItem, new MonitorItem { ItemName = "11" } };

                return containor;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace xQuant.LogParser
{
    /// <summary>
    /// 日志解析器
    /// </summary>
    public interface ILogParser
    {
        /// <summary>
        /// 解析指定的日志文件
        /// </summary>
        /// <param name="file">日志文件</param>
        /// <param name="itemList">监控项目列表</param>
        /// <returns>返回日志解析结果</returns>
        List<MonitorItemResult> Execute(LogFile file, IEnumerable<MonitorItem> itemList);
    }

    /// <summary>
    /// 日志解析器
    /// </summary>
    public class Parser : ILogParser
    {
        /// <summary>
        /// 解析指定的日志文件
        /// </summary>
        /// <param name="file">日志文件</param>
        /// <param name="itemList">监控项目列表</param>
        /// <returns>返回日志解析结果</returns>
        public List<MonitorItemResult> Execute(LogFile file, IEnumerable<MonitorItem> itemList)
        {
            Trace.Default.Write(string.Format("开始解析{0}", file.FileName));

            List<MonitorItemResult> result = null;
            var content = File.ReadAllText(file.FileName, Encoding.Default);
            if (!string.IsNullOrWhiteSpace(content))
            {
                result = this.DoExecute(file, content, itemList);
            }

            Trace.Default.Write(string.Format("完成解析{0}", file.FileName));

            foreach (var item in result)
            {
                Trace.Default.Write(item.ToString());
            }

            return result;
        }

        protected virtual List<MonitorItemResult> DoExecute(LogFile file, string content, IEnumerable<MonitorItem> itemList)
        {
            List<MonitorItemResult> resultList = new List<MonitorItemResult>();

            foreach (var item in itemList)
            {
                if (item.StartRegex != null)
                {
                    this.DoParseMatchValue(file.FileName, content, item.ItemName, item.StartRegex, resultList);
                }

                if (item.FinishRegex != null)
                {
                    this.DoParseMatchValue(file.FileName, content, item.ItemName, item.FinishRegex, resultList);
                }

                // 当父监控项目没有结果时，不处理子监控项目
                if (resultList.Count > 0 && item.HasChildren)
                {
                    resultList.AddRange(this.DoExecute(file, content, item.ChildList));
                }
            }

            return resultList;
        }

        private void DoParseMatchValue(string fileName, string content, string itemName, Regex regex, List<MonitorItemResult> resultList)
        {
            if (regex == null || string.IsNullOrWhiteSpace(content))
            {
                return;
            }

            string pattern = regex.ToString();
            Trace.Default.Write(string.Format("匹配{0}", pattern));

            var matches = regex.Matches(content);
            foreach (Match match in matches)
            {
                string value = match.Value;

                // 时间
                DateTime logtime;
                var part = value.Substring(0, 23);
                if (DateTime.TryParse(part, out logtime))
                {
                    // 判断当前匹配行是否满足时间要求

                }

                // 日志级别
                string ip = string.Empty;

                // 项目名称
                string customer = string.Empty;

                // 版本号
                string version = string.Empty;

                // 日志内容

                var itemResult = new MonitorItemResult
                {
                    FileName = fileName,
                    ItemName = itemName,
                    Pattern = pattern,
                    Version = version,
                    IPAddress = ip,
                    LogTime = part,
                    LogContent = string.Empty
                };

                resultList.Add(itemResult);
            }
        }
    }
}
﻿using System;

namespace xQuant.LogParser
{
    /// <summary>
    /// 日志文件
    /// </summary>
    public class LogFile
    {
        public string FileName { get; set; }
    }
}
﻿using System.Collections.Generic;

namespace xQuant.LogParser
{
    public class Analysis
    {
        public void Execute(IEnumerable<MonitorItemResult> itemList)
        {

        }
    }
}
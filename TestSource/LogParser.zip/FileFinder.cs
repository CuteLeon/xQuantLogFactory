﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace xQuant.LogParser
{
    /// <summary>
    /// 日志文件查找接口
    /// </summary>
    public interface ILogFileFinder
    {
        /// <summary>
        /// 查找符合日志分析参数的待分析日志文件清单
        /// </summary>
        /// <param name="param">日志分析参数</param>
        /// <returns>返回符合日志分析参数的待分析日志文件清单</returns>
        List<LogFile> Execute(AnalysisParam param);
    }

    /// <summary>
    /// 日志文件查找器
    /// </summary>
    public class FileFinder : ILogFileFinder
    {
        /// <summary>
        /// 查找符合日志分析参数的待分析日志文件清单
        /// </summary>
        /// <param name="param">日志分析参数</param>
        /// <returns>返回符合日志分析参数的待分析日志文件清单</returns>
        public List<LogFile> Execute(AnalysisParam param)
        {
            List<LogFile> fileList = new List<LogFile>();

            string path = param.BaseDirectory;
            if (string.IsNullOrWhiteSpace(path))
            {
                path = AppDomain.CurrentDomain.BaseDirectory;
            }

            if (Directory.Exists(path))
            {
                var files = Directory.GetFileSystemEntries(param.BaseDirectory);

                // todo:剔除明显不符合的日志文件


                fileList.AddRange(files.Select(x => new LogFile { FileName = x }));
            }

            // fileList.Sort( );

            return fileList;
        }
    }
}
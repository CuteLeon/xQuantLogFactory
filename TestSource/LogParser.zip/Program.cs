﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Serialization;
using xQuant.LogParser;

namespace ConsoleApplication28
{
    class Program
    {
        static void Main(string[] args)
        {
            //Test1();

            var parser = new LogParser();
            parser.Execute(args);

            Console.Read();
        }

        private static void Test()
        {
            MonitorItem rootItem = new MonitorItem
            {
                ItemName = "客户端启动",
                StartPattern = "客户端启动开始",
                FinishPatterny = "初始化第二阶段开始",
                ChildList = new List<MonitorItem>{  
                    new MonitorItem{ ItemName="数据加载",
                        StartPattern="加载中债参数设置表", 
                        FinishPatterny="加载当前登录部门",
                        ChildList= new List<MonitorItem>{
                            new MonitorItem{ 
                                ItemName="债券加载",
                                StartPattern="加载TBND查询", 
                                FinishPatterny="加载TBND"}}}
             }
            };

            MonitorContainer containor = new MonitorContainer();
            containor.ItemList = new List<MonitorItem> { rootItem, new MonitorItem { ItemName = "11" } };

            XmlSerializer serializer = new XmlSerializer(typeof(MonitorContainer));
            StringWriter writer = new StringWriter();
            serializer.Serialize(writer, containor);

            string value = writer.ToString();
            Console.WriteLine(value);

            Console.WriteLine("======================");

            StringReader reader = new StringReader(value);
            var obj = serializer.Deserialize(reader);
            Console.WriteLine(obj.ToString());
            Console.Read();
        }

        private static void Test1()
        {
            var content = File.ReadAllText(@"G:\wangwei\QQ\1467280434\FileRecv\Log\02SrvLog_Trace.txt", Encoding.Default);
            var regex = new Regex("^.*(加载TBND|加载TCMDT).*$", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Compiled);
            var matches = regex.Matches(content);
            foreach (Match match in matches)
            {
                Console.WriteLine(match.Value);
                foreach (Group group in match.Groups)
                {
                    Console.WriteLine(group.Value);
                }
            }
        }
    }
}
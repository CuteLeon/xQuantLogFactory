﻿namespace xQuant.LogParser
{
    /// <summary>
    /// 日志分析报告输出模式
    /// </summary>
    public enum ReportMode
    {
        /// <summary>
        /// 生成HTML
        /// </summary>
        Html = 1,

        /// <summary>
        /// 生成Word
        /// </summary>
        Word = 2,

        /// <summary>
        /// 生成Excel
        /// </summary>
        Excel = 3
    }

    /// <summary>
    /// 日志分析参数
    /// </summary>
    public class AnalysisParam
    {
        /// <summary>
        /// 日志文件目录
        /// </summary>
        public string BaseDirectory { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        public string StartTime { get; set; }

        /// <summary>
        /// 截止时间
        /// </summary>
        public string FinishTime { get; set; }

        /// <summary>
        /// 开始日期
        /// </summary>
        public string StartDay { get; set; }

        /// <summary>
        /// 截止日期
        /// </summary>
        public string FinishDay { get; set; }

        /// <summary>
        /// 包含系统信息
        /// </summary>
        public bool IncludeSystemInfo { get; set; }

        /// <summary>
        /// 包含客户端文件信息
        /// </summary>
        public bool IncludeClientInfo { get; set; }

        /// <summary>
        /// 日志分析报告输出模式
        /// </summary>
        public ReportMode Mode { get; set; }

        /// <summary>
        /// 监控的项目名称列表，以逗号分隔
        /// </summary>
        public string ItemName { get; set; }

        public static AnalysisParam Parse(string[] args)
        {
            var param = new AnalysisParam();

            param.BaseDirectory = @"G:\wangwei\QQ\1467280434\FileRecv\Log";

            return param;
        }
    }
}
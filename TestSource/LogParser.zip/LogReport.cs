﻿using System.Collections.Generic;

namespace xQuant.LogParser
{
    /// <summary>
    /// 日志分析报告输出
    /// </summary> 
    public class LogReportExporter
    {
        public void Execute(AnalysisParam param, List<MonitorItemResult> itemList)
        {

        }
    }
}